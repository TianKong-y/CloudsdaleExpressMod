package com.smoothquartz.minecart.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record HandshakePayload(String message) implements class_8710 {

    public static final class_2960 CHANNEL = class_2960.method_60655("smoothquartz", "handshake");
    public static final class_8710.class_9154<HandshakePayload> ID = new class_8710.class_9154<>(CHANNEL);
    public static final class_9139<class_9129, HandshakePayload> CODEC = class_9139.method_56434(
        class_9135.field_48554,
        HandshakePayload::message,
        HandshakePayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
