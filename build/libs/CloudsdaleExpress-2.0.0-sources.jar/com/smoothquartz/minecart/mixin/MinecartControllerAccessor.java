package com.smoothquartz.minecart.mixin;

import net.minecraft.class_1688;
import net.minecraft.class_9878;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_9878.class)
public interface MinecartControllerAccessor {

    @Accessor("minecart")
    class_1688 smoothquartz$getMinecart();
}
