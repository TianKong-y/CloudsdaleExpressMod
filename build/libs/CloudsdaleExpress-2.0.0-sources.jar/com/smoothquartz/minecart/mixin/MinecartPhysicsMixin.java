package com.smoothquartz.minecart.mixin;

import com.smoothquartz.minecart.ModPlayerManager;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_9879;
import net.minecraft.class_9883;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_9883.class, class_9879.class})
public abstract class MinecartPhysicsMixin {

    @Unique
    private static final double HIGH_SPEED_MAX = 1.75D;

    @Unique
    private static final double NORMAL_SPEED_MAX = 0.4D;

    @Unique
    private static final double SOFT_DECEL_PER_TICK = 0.055D;

    @Unique
    private static final double EPSILON = 1.0E-6D;

    @Unique
    private double smoothquartz$softCap = NORMAL_SPEED_MAX;

    @Unique
    private boolean smoothquartz$softDecelActive = false;

    @Unique
    private net.minecraft.class_1688 smoothquartz$getMinecart() {
        return ((MinecartControllerAccessor) this).smoothquartz$getMinecart();
    }

    @Unique
    private boolean isOnSmoothQuartzRail() {
        var minecart = smoothquartz$getMinecart();
        class_2338 railPos = minecart.method_24515();
        class_2680 railBlock = minecart.method_37908().method_8320(railPos);
        class_2680 below = minecart.method_37908().method_8320(railPos.method_10074());
        return railBlock.method_27852(class_2246.field_9978) || below.method_27852(class_2246.field_9978);
    }

    @Unique
    private boolean hasHighSpeedPermission() {
        class_1297 passenger = smoothquartz$getMinecart().method_31483();
        if (!(passenger instanceof class_1657 player)) {
            return true;
        }

        // Keep server-side tracking support, but do not hard-block local/client behavior.
        if (smoothquartz$getMinecart().method_37908().method_8608()) {
            return true;
        }
        return ModPlayerManager.hasMod(player.method_5667()) || smoothquartz$getMinecart().method_37908().method_8503() == null;
    }

    @Unique
    private boolean shouldEnableHighSpeed() {
        return isOnSmoothQuartzRail() && hasHighSpeedPermission();
    }

    @Unique
    private double horizontalSpeed(class_243 velocity) {
        return Math.sqrt(velocity.field_1352 * velocity.field_1352 + velocity.field_1350 * velocity.field_1350);
    }

    @Inject(method = "getMaxSpeed", at = @At("RETURN"), cancellable = true)
    private void onGetMaxSpeed(class_3218 world, CallbackInfoReturnable<Double> cir) {
        if (shouldEnableHighSpeed()) {
            smoothquartz$softDecelActive = false;
            smoothquartz$softCap = HIGH_SPEED_MAX;
            cir.setReturnValue(HIGH_SPEED_MAX);
            return;
        }

        if (smoothquartz$softDecelActive && smoothquartz$softCap > NORMAL_SPEED_MAX + EPSILON) {
            cir.setReturnValue(Math.min(cir.getReturnValue(), smoothquartz$softCap));
            return;
        }

        smoothquartz$softDecelActive = false;
        smoothquartz$softCap = NORMAL_SPEED_MAX;
        cir.setReturnValue(Math.min(cir.getReturnValue(), NORMAL_SPEED_MAX));
    }

    @Inject(method = "moveOnRail", at = @At("TAIL"))
    private void onMoveOnRail(class_3218 world, CallbackInfo ci) {
        var minecart = smoothquartz$getMinecart();
        class_243 velocity = minecart.method_18798();
        double horizontal = horizontalSpeed(velocity);
        if (horizontal <= 0.0D) {
            return;
        }

        if (shouldEnableHighSpeed()) {
            smoothquartz$softDecelActive = false;
            smoothquartz$softCap = HIGH_SPEED_MAX;
            return;
        }

        if (horizontal <= NORMAL_SPEED_MAX + EPSILON) {
            smoothquartz$softDecelActive = false;
            smoothquartz$softCap = NORMAL_SPEED_MAX;
            return;
        }

        if (!smoothquartz$softDecelActive) {
            smoothquartz$softDecelActive = true;
            smoothquartz$softCap = Math.min(HIGH_SPEED_MAX, horizontal);
        }

        smoothquartz$softCap = Math.max(NORMAL_SPEED_MAX, smoothquartz$softCap - SOFT_DECEL_PER_TICK);

        if (horizontal > smoothquartz$softCap) {
            double factor = smoothquartz$softCap / horizontal;
            minecart.method_18800(velocity.field_1352 * factor, velocity.field_1351, velocity.field_1350 * factor);
        }

        if (smoothquartz$softCap <= NORMAL_SPEED_MAX + EPSILON) {
            smoothquartz$softDecelActive = false;
        }
    }
}
