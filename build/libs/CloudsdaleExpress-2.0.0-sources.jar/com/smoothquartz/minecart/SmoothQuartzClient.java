package com.smoothquartz.minecart;

import java.lang.reflect.Method;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_634;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class SmoothQuartzClient implements ClientModInitializer {

    private static final Logger LOGGER = LoggerFactory.getLogger("SmoothQuartz-Client");
    private static final int HANDSHAKE_DELAY_TICKS = 20;

    private static boolean needsHandshake;
    private static int delayTicks;

    @Override
    public void onInitializeClient() {
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            needsHandshake = true;
            delayTicks = HANDSHAKE_DELAY_TICKS;
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            needsHandshake = false;
            delayTicks = 0;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!needsHandshake || client.field_1724 == null) {
                return;
            }

            if (delayTicks > 0) {
                delayTicks--;
                return;
            }

            class_634 networkHandler = client.method_1562();
            if (networkHandler == null) {
                return;
            }

            sendHandshakeCommand(networkHandler);
            needsHandshake = false;
        });

        LOGGER.info("SmoothQuartz client initialized");
    }

    private void sendHandshakeCommand(class_634 handler) {
        if (tryInvokeSendCommand(handler, "sqm handshake")) {
            return;
        }

        // Yarn mapping on this environment exposes sendChatCommand instead of sendCommand.
        handler.method_45730("sqm handshake");
    }

    private boolean tryInvokeSendCommand(class_634 handler, String command) {
        try {
            Method method = handler.getClass().getMethod("sendCommand", String.class);
            method.invoke(handler, command);
            return true;
        } catch (ReflectiveOperationException ex) {
            return false;
        }
    }
}
